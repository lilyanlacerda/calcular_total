function calcularTotal(ferramentas, comprar) {
    if (ferramentas.length === 0 || comprar.length === 0) {
        throw new Error("Ambas as listas precisam ter ao menos um item.");
    }

    const listaFerramentasDisponiveis = {};
    for (let indice = 0; indice < ferramentas.length; indice++) {
        const ferramenta = ferramentas[indice];
        listaFerramentasDisponiveis[ferramenta.nome] = ferramenta.preco;
    }

    let total = 0;
    for (let indice = 0; indice < comprar.length; indice++) {
        const nome = comprar[indice];

        let encontrou = false;
        const chaves = Object.keys(listaFerramentasDisponiveis);
        for (let i = 0; i < chaves.length; i++) {
            const key = chaves[i];
            if (key === nome) {
                total += listaFerramentasDisponiveis[key];
                encontrou = true;
                break;
            }
        }
        
        if (!encontrou) {
            throw new Error("Nenhuma ferramenta desejada encontrada.");;
        }
    }


    const listaFerramentas = comprar.join(", ");
    return `O valor a pagar pelas ferramentas (${listaFerramentas}) é R$ ${total.toFixed(2)}`;
}

module.exports = {
    calcularTotal
}